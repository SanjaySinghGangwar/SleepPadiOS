//
//  P3XSearchDeviceTableViewCell.h
//  QLife
//
//  Created by admin on 2018/6/4.
//  Copyright © 2018年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchDeviceTableViewCell : UITableViewCell
@property (strong,nonatomic)UILabel *lineLabel;
@property (strong,nonatomic)UILabel *deviceNameLabel;
@end
