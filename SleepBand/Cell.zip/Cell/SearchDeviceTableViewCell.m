//
//  SearchDeviceTableViewCell.m
//  QLife
//
//  Created by admin on 2018/6/4.
//  Copyright © 2018年 admin. All rights reserved.
//

#import "SearchDeviceTableViewCell.h"
#define cellHeight 50

@implementation SearchDeviceTableViewCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self setUI];
    }
    return self;
}
-(void)setUI{
    self.deviceNameLabel = [[UILabel alloc]initWithFrame:CGRectMake(24, 0, kSCREEN_WIDTH-42, cellHeight-1)];
    self.deviceNameLabel.font = [UIFont systemFontOfSize:15];
    self.deviceNameLabel.textAlignment = NSTextAlignmentLeft;
    self.deviceNameLabel.textColor = [UIColor colorWithHexString:@"#38393e"];
    [self.contentView addSubview:self.deviceNameLabel];
    
    self.lineLabel = [[UILabel alloc]initWithFrame:CGRectMake(12, cellHeight-1, kSCREEN_WIDTH-24, 1)];
    self.lineLabel.backgroundColor = [UIColor colorWithHexString:@"#9c9c9f"];
    [self.contentView addSubview:self.lineLabel];
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
