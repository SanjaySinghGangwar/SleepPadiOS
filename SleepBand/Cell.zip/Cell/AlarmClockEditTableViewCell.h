//
//  AlarmClockEditTableViewCell.h
//  SleepBand
//
//  Created by admin on 2018/7/11.
//  Copyright © 2018年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^switchBlock)(BOOL isOn);

@interface AlarmClockEditTableViewCell : UITableViewCell
@property (strong,nonatomic) UILabel *menuNameLabel;
@property (strong,nonatomic) UILabel *valueLabel;
@property (strong,nonatomic) UISwitch *switchBtn;
@property (copy,nonatomic) switchBlock switchBlock;
@end
