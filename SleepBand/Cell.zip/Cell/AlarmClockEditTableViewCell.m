//
//  AlarmClockEditTableViewCell.m
//  SleepBand
//
//  Created by admin on 2018/7/11.
//  Copyright © 2018年 admin. All rights reserved.
//

#import "AlarmClockEditTableViewCell.h"

@implementation AlarmClockEditTableViewCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if(self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]){
        [self setUI];
    }
    return self;
}
-(void)setUI{
    
    self.contentView.backgroundColor = [UIColor colorWithHexString:@"#ffffff"];
    
    WS(weakSelf);
    self.menuNameLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    self.menuNameLabel.font = [UIFont systemFontOfSize:16];
    self.menuNameLabel.textColor = [UIColor colorWithHexString:@"#4d4d4d"];
    [self.contentView addSubview:self.menuNameLabel];
    [self.menuNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(weakSelf.contentView.mas_right).offset(-150);
        make.left.mas_equalTo(weakSelf.contentView.mas_left).offset(15);
        make.top.bottom.equalTo(weakSelf.contentView);
    }];
    
    self.switchBtn = [[UISwitch alloc]init];
    [self.contentView addSubview:self.switchBtn];
    self.switchBtn.hidden = YES;
    [self.switchBtn addTarget:self action:@selector(switchBtn:) forControlEvents:UIControlEventTouchUpInside];
    [self.switchBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(weakSelf.contentView.mas_right).offset(-15);
        make.centerY.equalTo(weakSelf.contentView);
    }];
    
    self.valueLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    self.valueLabel.font = [UIFont systemFontOfSize:15];
    self.valueLabel.textColor = [UIColor colorWithHexString:@"#4d4d4d"];
    [self.contentView addSubview:self.valueLabel];
    self.valueLabel.textAlignment = NSTextAlignmentRight;
    self.valueLabel.hidden = YES;
    [self.valueLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(weakSelf.contentView.mas_right).offset(-15);
        make.left.mas_equalTo(weakSelf.menuNameLabel.mas_right).offset(0);
        make.top.bottom.equalTo(weakSelf.contentView);
    }];
    
    UILabel *lineLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    lineLabel.backgroundColor = [UIColor colorWithHexString:@"#a5a5a5"];
    [self.contentView addSubview:lineLabel];
    [lineLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(weakSelf.contentView).offset(0);
        make.width.equalTo(@(kSCREEN_WIDTH));
        make.height.equalTo(@1);
    }];
    
}
-(void)switchBtn:(UISwitch *)sender{
    self.switchBlock(sender.isOn);
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
